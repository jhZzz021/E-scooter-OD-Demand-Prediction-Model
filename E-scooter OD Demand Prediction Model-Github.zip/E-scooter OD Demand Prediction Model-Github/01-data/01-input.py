import pandas as pd
import numpy as np
# Load data
weather_data = pd.read_csv('trip_weather.csv')
distance = pd.read_csv('spatial_distance_matrix.csv')
hourly_trip_counts = np.load('trip_count_100_578_289.npy')

# Define constants
num_locations_start = 578
num_locations_end = 17*17
hours = 100
n_hours = 6
n_features = num_locations_start * num_locations_end
split_ratio = 0.8

distance_reshaped = distance.values.flatten()
distance_repeated = np.tile(distance_reshaped, num_locations_start).reshape(num_locations_start, num_locations_end)
distance_df = pd.DataFrame(distance_repeated)

# Preprocessing for model
samples = len(hourly_trip_counts) - n_hours
inputs = np.zeros((samples, n_hours, n_features))
outputs = np.zeros((samples, 3-2, n_features))
weather = np.zeros((samples, n_hours, n_features))
for i in range(samples):
    inputs[i] = hourly_trip_counts[i:i+n_hours].reshape(n_hours, -1)
    outputs[i] = hourly_trip_counts[i+n_hours:i+n_hours+3-2].reshape(3-2, -1)

print('finish')