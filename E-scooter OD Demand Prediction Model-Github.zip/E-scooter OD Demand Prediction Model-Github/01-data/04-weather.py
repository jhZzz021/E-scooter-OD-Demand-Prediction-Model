import pandas as pd
import numpy as np
# Load data
weather_data = pd.read_csv('trip_weather.csv')
# Load data
#weather_data = pd.read_csv('../01-InputData/02-input/trip_weather.csv')
# 假设Is-holiday是DataFrame的列名
weather_data['Is_Holiday'] = weather_data['Is_Holiday'].astype(int)
from sklearn.preprocessing import LabelEncoder
# 创建 LabelEncoder 对象
label_encoder = LabelEncoder()
# 假设 'Day_of_weeks' 和 'conditions' 是 DataFrame 的列名
weather_data['Day_of_week'] = label_encoder.fit_transform(weather_data['Day_of_week'])
weather_data['conditions'] = label_encoder.fit_transform(weather_data['conditions'])
# 将 DataFrame 转换为 Numpy 数组
weather_array = weather_data.values
from sklearn.preprocessing import OneHotEncoder
# 提取后三列作为类别变量
categorical_data = weather_array[:, -3:]
# 创建 OneHotEncoder 对象
onehot_encoder = OneHotEncoder(sparse=False)
# 对类别变量进行独热编码
categorical_data_onehot = onehot_encoder.fit_transform(categorical_data)
# 前面的连续型特征
continuous_features = weather_array[:, :-3]
# 合并连续型特征和独热编码后的类别变量
weather_array_encoded = np.concatenate((continuous_features, categorical_data_onehot), axis=1)

# Define constants
num_locations_start = 578
num_locations_end = 17*17
hours = 100
n_hours = 6
n_features = num_locations_start * num_locations_end
split_ratio = 0.8
# Preprocessing for model
samples = len(weather_data) - n_hours - 2 +2
#inputs = np.zeros((samples, n_hours, n_features))
#outputs = np.zeros((samples, 3-2, n_features))
weather = np.zeros((samples, n_hours, 15))
print('1')
for i in range(samples):
    weather[i] = weather_array_encoded[i:i + n_hours].reshape(n_hours, -1)
    #inputs[i] = hourly_trip_counts[i:i + n_hours].reshape(n_hours, -1)
    #outputs[i] = hourly_trip_counts[i + n_hours:i + n_hours + 3 - 2].reshape(3 - 2, -1)
np.save('04-weather_data_100_6_15.npy', weather)
#np.save('inputs_data_3522_6_20.npy', inputs)
#np.save('output_data_3522_6_20.npy', outputs)
print('finish')
