import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Load data
weather_data = pd.read_csv('../01-data/trip_weather.csv')
distance = pd.read_csv('../01-data/spatial_distance_matrix.csv')
hourly_trip_counts = np.load('../01-data/trip_count_100_578_289.npy')

# Define constants
num_locations_start = 578
num_locations_end = 17*17
hours = 100
n_hours = 6
n_features = num_locations_start * num_locations_end
split_ratio = 0.8

distance_reshaped = distance.values.flatten()
distance_repeated = np.tile(distance_reshaped, num_locations_start).reshape(num_locations_start, num_locations_end)
distance_df = pd.DataFrame(distance_repeated)
adjacency_matrix = distance_df.values

# Preprocessing for model
samples = len(hourly_trip_counts) - n_hours - 2+2
inputs = np.zeros((samples, n_hours, n_features))
outputs = np.zeros((samples, 3-2, n_features))
weather = np.zeros((samples, n_hours, n_features))
for i in range(samples):
    inputs[i] = hourly_trip_counts[i:i+n_hours].reshape(n_hours, -1)
    outputs[i] = hourly_trip_counts[i+n_hours:i+n_hours+3-2].reshape(3-2, -1)

# Preprocessing for model
n_predictions = 1  # 预测未来1个时间步
samples = len(hourly_trip_counts) - n_hours - (n_predictions - 1)

inputs = torch.from_numpy(inputs).float()
outputs = torch.from_numpy(outputs).float()

# Split data
train_size = int(split_ratio * samples)
test_size = samples - train_size
train_inputs = inputs[:train_size]
train_outputs = outputs[:train_size]
test_inputs = inputs[train_size:]
test_outputs = outputs[train_size:]

class SpatioTemporalModelWithAttention(nn.Module):
    def __init__(self, adjacency_matrix, hidden_dim=50):
        #CNN+BiLSTM
        super(SpatioTemporalModelWithAttention, self).__init__()
        self.hidden_dim = hidden_dim
        self.spatial_conv = nn.Conv3d(1, 1, kernel_size=(3, 3, 3), padding=1)
        self.lstm = nn.LSTM(input_size=n_features, hidden_size=hidden_dim, num_layers=3, batch_first=True, bidirectional=False)
        self.attention = nn.Linear(hidden_dim, 1)  # 定义注意力层
        self.fc = nn.Linear(hidden_dim, n_features * n_predictions)
        self.adjacency_matrix = torch.from_numpy(adjacency_matrix).float().unsqueeze(0).unsqueeze(0)

    def forward(self, x):
        x = x.reshape(-1, n_hours, num_locations_start, num_locations_end)
        x = x.unsqueeze(1)
        x = self.spatial_conv(x)
        x = x.squeeze(1)
        x = x.reshape(-1, n_hours, n_features)
        lstm_out, _ = self.lstm(x)
        # attention
        attention_weights = torch.softmax(self.attention(lstm_out), dim=1)
        context = torch.sum(attention_weights * lstm_out, dim=1)
        output = self.fc(context)
        output = output.reshape(-1, n_features * n_predictions)
        return output

# 初始化模型
model = SpatioTemporalModelWithAttention(adjacency_matrix)
# Define optimizer and loss function
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
loss_fn = nn.MSELoss()

# Train model
for epoch in range(3):
    model.train()
    optimizer.zero_grad()
    outputs_pred = model(train_inputs)
    loss = loss_fn(outputs_pred, train_outputs)
    loss.backward()
    optimizer.step()

    if epoch % 2 == 0:
        model.eval()
        with torch.no_grad():
            predictions = model(test_inputs)
            mse = mean_squared_error(test_outputs.numpy().flatten(), predictions.numpy().flatten())
            mae = mean_absolute_error(test_outputs.numpy().flatten(), predictions.numpy().flatten())
            rmse = np.sqrt(mean_squared_error(test_outputs.numpy().flatten(), predictions.numpy().flatten()))
            print(f'Epoch: {epoch}, Loss: {loss.item()}, MSE: {mse}, MAE: {mae}, RMSE: {rmse}')

print('finish')