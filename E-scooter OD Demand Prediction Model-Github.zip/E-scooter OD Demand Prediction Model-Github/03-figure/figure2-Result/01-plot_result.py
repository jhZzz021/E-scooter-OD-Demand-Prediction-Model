import pandas as pd
import geopandas as gpd
import numpy as np
# Load data
gdf_polygons = gpd.read_file('./shapefile/new_zones_id.shp', encoding='utf-8').to_crs(epsg=4326)
data = pd.read_csv('trip_information.csv') # part of data
data = data[['hour_number', 'start_zone_id', 'end_zone_id']]

start_counts = data['start_zone_id'].value_counts().reset_index()
start_counts.columns = ['start_zone_id', 'start_count']
start_counts['start_count'] = start_counts['start_count']/3520

merged_df = pd.merge(gdf_polygons, start_counts, how='left', left_on='ZoneID', right_on='start_zone_id')
merged_df['start_count'].fillna(0, inplace=True)
import matplotlib.pyplot as plt


fig, ax = plt.subplots(1, 1, figsize=(8, 6))
merged_df.plot(column='start_count', cmap='viridis', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True,
               vmin=0, vmax=2)  # 使用 vmin 和 vmax 设置颜色映射的最小值和最大值
"""
# 添加色度条
sm = plt.cm.ScalarMappable(cmap='viridis', norm=plt.Normalize(vmin=0, vmax=3))
sm._A = []  # 这行可能是必需的，以避免某些版本的Matplotlib产生错误
cbar = fig.colorbar(sm, ax=ax)
"""

# 美化图表
ax.set_title('Ground data')
#ax.set_title('Prediction result for model (CNN-BiLSTM-Attention-Weather)')
ax.set_xticks([])
ax.set_yticks([])

plt.savefig('Ground data.png', dpi=300, bbox_inches='tight')

plt.show()